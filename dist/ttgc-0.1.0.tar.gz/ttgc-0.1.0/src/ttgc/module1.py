import numpy as np

a=np.ones(1)
return a